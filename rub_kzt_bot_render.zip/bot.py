import asyncio
import requests
import json
import os
import matplotlib.pyplot as plt
from datetime import datetime
from aiogram import Bot, Dispatcher
from aiogram.types import FSInputFile
from apscheduler.schedulers.asyncio import AsyncIOScheduler

BOT_TOKEN = os.getenv("BOT_TOKEN", "7903179717:AAFPqvzV_f1XrHSJFY2-wFRRwvksLlKJ6e8")
CHANNEL_ID = int(os.getenv("CHANNEL_ID", "-1002597305168"))

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher()
scheduler = AsyncIOScheduler()

HISTORY_FILE = "history.json"

def load_history():
    if not os.path.exists(HISTORY_FILE):
        return []
    with open(HISTORY_FILE, "r") as f:
        return json.load(f)

def save_history(history):
    with open(HISTORY_FILE, "w") as f:
        json.dump(history, f)

def generate_chart(history):
    timestamps = [x["time"] for x in history]
    rub_kzt_values = [x["rub_kzt"] for x in history]

    plt.figure(figsize=(10, 5))
    plt.plot(timestamps, rub_kzt_values, marker='o', color='blue')
    plt.title("Курс RUB -> KZT")
    plt.xlabel("Время")
    plt.ylabel("Курс")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig("chart.png")
    plt.close()

async def check_currency():
    url = "https://api.exchangerate.host/latest?base=RUB&symbols=KZT"
    response = requests.get(url).json()
    rub_kzt = round(response["rates"]["KZT"], 2)
    time_now = datetime.now().strftime("%Y-%m-%d %H:%M")

    history = load_history()
    if not history or history[-1]["rub_kzt"] != rub_kzt:
        history.append({"time": time_now, "rub_kzt": rub_kzt})
        if len(history) > 30:
            history = history[-30:]
        save_history(history)
        generate_chart(history)

        caption = f"🇷🇺 1 RUB = 🇰🇿 {rub_kzt} KZT\nОбновлено: {time_now}"
        await bot.send_photo(CHANNEL_ID, photo=FSInputFile("chart.png"), caption=caption)

async def main():
    scheduler.add_job(check_currency, "interval", hours=1)
    scheduler.start()
    await check_currency()
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())